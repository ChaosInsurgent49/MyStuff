This application is built for Windows ONLY. It was compiled using the U64 compiler on a 64-bit Windows 10 installation and as such, may not function well on other operating system versions.

Now, onto some explanations for the application and its configuration file.

====Application====
The application opens into a state in which it is always on top and cannot be clicked. Toggle clickthrough in order to be able to move the panel.

Press Control+Win+R to open the menu
Press Control+Win+E to toggle window clickthrough

====Menu====

==Schedule Select==
Click on an option to set the schedule to that option.

==Time Format==
Click on an option to set the format of the period and time remaining slots to one of four options:
1 - Display date in YYYY-MM-DD followed by the day of the year
2 - Display period followed by the time until the next period
3 - Display period followed by a different variant of the time until the next period
4 - Display date in YYYY-MM-DD followed by the time until the next period

==Status Panel Opacity==
Choose between the default (200), full opacity (255), and the currently saved value, or add/subtract opacity.

====Configuration====

Debug currently has no function.
Settings.useLast selects whether to use the last value for the specified variable, with 0 for false and 1 for true.
Settings.autoTimeChoice automatically selects a schedule based on the day of the week, using indexes starting from 1.
Settings.autoFormatChoice automatically selects the specified time format, which is a number from 1 to 4.
Settings.compactMode has no function.
Settings.haveMargine is the number to subtract from the time remaining before the next part of the schedule in seconds, recommended valus are 0 and 1.
Settings.isDesktop is 0 for false and 1 for true.
Settings.colors is self explanatory and can be figured out through experimentation.
Settings.font is self explanatory and can be figured out through experimentation.
Settings.textOffset is values to offset the x and y coordinates of text labels to best fit different fonts.
Times are the schedules, further elaboration will be included in a future update.
BatteryColoration sets the color of the battery bar based on the amount of battery left, further elaboration will be included in a future update.
